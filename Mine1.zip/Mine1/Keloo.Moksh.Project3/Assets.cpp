#include "Assets.h"
#include "Mine.h"
#include "ButtonClass.h"
#include "DigitCounter.h"
#include "TileState.h"
#include "PlaceFlags.h"
#include "PlaceCheckerMines.h"
#include "FaceButton.h"

using namespace std;

/* **************************** FaceButton **************************** */

// Default constructor for FaceButton
FaceButton::FaceButton() : ButtonClass() {
    // Set the face of button to happy
    this->face = happy;
    // Set the texture based on the face of button
    if (face == happy) {
        setTexture("./images/face_happy.png");
    } else if (face == win) {
        setTexture("./images/face_win.png");
    }
    else if (face == lose) {
        setTexture("./images/face_lose.png");
    }
    // Set the sprite based on the texture
    setSprite();
}

// Constructor for FaceButton with position and face
FaceButton::FaceButton(Vector2f position, Face face) {
    // Set the face of button
    this->face = face;
    // Set the position of the button
    setPosition(position);
    // Set the texture based on the face of button
    if (face == happy) {
        setTexture("./images/face_happy.png");
    } else if (face == win) {
        setTexture("./images/face_win.png");
    }
    else if (face == lose) {
        setTexture("./images/face_lose.png");
    }
    // Set the sprite based on the texture
    setSprite();
}

// Constructor for FaceButton with x and y coordinates and face
FaceButton::FaceButton(float x, float y, Face face) {
    // Set the face of button
    this->face = face;
    // Set the position of the button
    setPosition(x, y);
    // Set the texture based on the face of button
    if (face == happy) {
        setTexture("./images/face_happy.png");
    } else if (face == win) {
        setTexture("./images/face_win.png");
    }
    else if (face == lose) {
        setTexture("./images/face_lose.png");
    }
    setSprite();
}

void FaceButton::setFace(Face face) {
    // Set the face of button
    this->face = face;
    // Set the texture based on the face of button
    if (face == happy) {
        setTexture("./images/face_happy.png");
    } else if (face == win) {
        setTexture("./images/face_win.png");
    }
    else if (face == lose) {
        setTexture("./images/face_lose.png");
    }
    // Set the sprite based on the texture
    setSprite();
}


/* **************************** PlaceCheckerMines (MineCounter) **************************** */

PlaceCheckerMines::PlaceCheckerMines() {
    // sets the position to (0,0)
    setPosition(0,0);
    this->count = 0;
    for (unsigned int i = 0; i < 8; i++) {
        try {
            // tries to load texture from file
            this->textures[i].loadFromFile("./images/number_" + to_string(i + 1) + ".png");
        } catch (exception e) {
            // catches any exceptions thrown by loadFromFile but does not handle them
        }
        // creates a sprite for each texture
        this->sprites[i] = Sprite(this->textures[i]);
        // sets the position of each sprite to the position of the PlaceCheckerMines instance
        this->sprites[i].setPosition(position.x, position.y);
    }
}

// constructor that takes x and y as arguments
PlaceCheckerMines::PlaceCheckerMines(float x, float y) {
    // sets the position of the PlaceCheckerMines instance to the given x and y values
    setPosition(x,y);
    this->count = 0;
    for (unsigned int i = 0; i < 8; i++) {
        try {
            this->textures[i].loadFromFile("./images/number_" + to_string(i + 1) + ".png");
        } catch (exception e) {}
        this->sprites[i] = Sprite(this->textures[i]);
        this->sprites[i].setPosition(position.x, position.y);
    }
}

PlaceCheckerMines::PlaceCheckerMines(int count, float x, float y) {
    // sets the position of the PlaceCheckerMines instance to the given x and y
    setPosition(x,y);
    this->count = count;
    for (unsigned int i = 0; i < 8; i++) {
        try {
            // tries to load texture from file
            this->textures[i].loadFromFile("./images/number_" + to_string(i + 1) + ".png");
        } catch (exception e) {
            // catches any exceptions thrown by loadFromFile but does not handle them
        }
        this->sprites[i] = Sprite(this->textures[i]);
        this->sprites[i].setPosition(position.x, position.y);
    }
}

// sets the count of the PlaceCheckerMines instance to the given count
void PlaceCheckerMines::setCount(int count) {
    this->count = count;
}


/* **************************** PlaceFlags **************************** */

// Default constructor for PlaceFlags
PlaceFlags::PlaceFlags() {
    setPosition(0,0);
    setTexture("./images/flag.png");
    setSprite();
    setState(hidden);
}

// Constructor for PlaceFlags with position
PlaceFlags::PlaceFlags(Vector2f position) {
    setPosition(position);
    setTexture("./images/flag.png");
    setSprite();
    setState(hidden);
}

// Constructor for PlaceFlags with x and y coordinates
PlaceFlags::PlaceFlags(float x, float y) {
    setPosition(x,y);
    setTexture("./images/flag.png");
    setSprite();
    setState(hidden);
}

// sets the state of the PlaceFlags instance to the given state
void PlaceFlags::setState(State state) {
    this->state = state;
}


/* **************************** TileState **************************** */

    // This is the default constructor for the TileState class
    TileState::TileState() {
    // Initialize a new PlaceFlags object and assign it to the flag attribute
    this->flag = new PlaceFlags();
    // Set the state of the tile to hidden
    this->state = hidden;
    // Set the hasMine attribute to false
    this->hasMine = false;
    // Set the texture for the tile
    Assets::setTexture("./images/tile_hidden.png");
    // Set the sprite for the tile
    setSprite();
    // Initialize a new PlaceCheckerMines object and assign it to the counter attribute
    this->counter = new PlaceCheckerMines();
}

    // This is a constructor for the TileState class that takes in values for the state, position, and hasMine attributes
TileState::TileState(State state, Vector2f position, bool hasMine) {
    // Initialize a new PlaceFlags object with the specified position and assign it to the flag attribute
    this->flag = new PlaceFlags(position);
    // Set the state of the tile to the specified value
    this->state = state;
    // Set the hasMine attribute to the specified value
    this->hasMine = hasMine;

    // Set the position of the tile to the specified value
    setPosition(position);

    // Set the texture for the tile based on its state
    if (state == hidden) {
        Assets::setTexture("./images/tile_hidden.png");
    } else {
        Assets::setTexture("./images/tile_revealed.png");
    }
    // Set the sprite for the tile
    setSprite();
    // Initialize a new PlaceCheckerMines object with the specified position and assign it to the counter attribute
    this->counter = new PlaceCheckerMines(position.x, position.y);
}

// This is the constructor for the TileState class. It initializes the tile's state, position, and whether or not it has a mine.
// It also sets the texture for the tile based on its state.
TileState::TileState(State checkState, float x, float y, bool hasMine) {
    this->flag = new PlaceFlags(x, y); // create a new PlaceFlags object at the given position
    this->state = checkState; // set the state of the tile
    this->hasMine = hasMine; // set whether or not the tile has a mine
    setPosition(x, y); // set the position of the tile
    if (checkState == hidden) { // if the state is hidden
        Assets::setTexture("./images/tile_hidden.png"); // set the texture to the "hidden" texture
    } else { // if the state is not hidden
        Assets::setTexture("./images/tile_revealed.png"); // set the texture to the "revealed" texture
    }
    setSprite(); // set the sprite for the tile
    this->counter = new PlaceCheckerMines(x, y); // create a new PlaceCheckerMines object at the given position
}

// This function sets the state of the tile.
void TileState::setState(State checkState) {
    this->state = checkState; // set the state of the tile
    this->setTexture(checkState); // set the texture for the tile based on the new state
}

// This function sets whether or not the tile has a mine.
void TileState::setHasMine(bool hasMine) {
    this->hasMine = hasMine; // set whether or not the tile has a mine
}

// This function sets the texture for the tile based on its state.
void TileState::setTexture(State checkState) {
    if (checkState == hidden) { // if the state is hidden
        Assets::setTexture("./images/tile_hidden.png"); // set the texture to the "hidden" texture
    } else if (checkState == revealed) { // if the state is revealed
        Assets::setTexture("./images/tile_revealed.png"); // set the texture to the "revealed" texture
    }
}

// This function uncovers any adjacent tiles that do not have mines.
void TileState::uncoverAdjacent() {
    int count = 0; // variable to store the number of adjacent tiles that have mines
    for (unsigned int i = 0; i < adjacentTiles.size(); i++) { // iterate through the list of adjacent tiles
        if (adjacentTiles[i]->hasMine) { // if the current tile has a mine
            count++; // increment the count of adjacent tiles with mines
        }
    }
    if (count != 0) { // if there are adjacent tiles with mines
        this->counter->setCount(count); // set the mine count for the tile
        this->counter->position = position; // set the position of the mine counter
    } else { // if there are no adjacent tiles with mines
        for (unsigned int i = 0; i < adjacentTiles.size(); i++) { // iterate through the list of adjacent tiles
            if (adjacentTiles[i]->state == hidden) { // if the current tile is hidden
                for (unsigned int j = 0; j < adjacentTiles[i]->adjacentTiles.size(); j++) { // iterate through the list of adjacent tiles
                    if (adjacentTiles[i]->adjacentTiles[j]->hasMine == false) { // if the current tile does not have a mine
                        if (adjacentTiles[i]->flag->state != revealed) { // if the current tile is not revealed
                            adjacentTiles[i]->setState(revealed); // set the state of the current tile to revealed
                            adjacentTiles[i]->uncoverAdjacent(); // uncover any adjacent tiles to the current tile
                        }
                    }
                }
            }
        }
    }
}

// Destructor for the TileState class.
TileState::~TileState() {
    delete flag;
    delete counter;
}


/* **************************** DigitCounter **************************** */

// Default constructor for the DigitCounter class.
DigitCounter::DigitCounter() {
    // Initialize the digits array with default values.
    this->digits[0] = 0;
    this->digits[1] = 5;
    this->digits[2] = 0;

    // Set the position of the DigitCounter instance using the setPosition method.
    setPosition(0, 32 * 16);

    // Set the texture of the DigitCounter instance using the setTexture method.
    setTexture("./images/digits.png");

    // Create three Sprite objects using the texture of the DigitCounter instance.
    this->sprites[0] = Sprite(texture);
    this->sprites[1] = Sprite(texture);
    this->sprites[2] = Sprite(texture);

    // Set the position of each sprite using the position of the DigitCounter instance.
    this->sprites[0].setPosition(position);
    this->sprites[1].setPosition(position.x + 21, position.y);
    this->sprites[2].setPosition(position.x + 42, position.y);

    // Set the texture rect of each sprite using the corresponding digit in the digits array.
    this->sprites[0].setTextureRect(IntRect(0 + 21 * this->digits[0], 0, 21, 32));
    this->sprites[1].setTextureRect(IntRect(0 + 21 * this->digits[1], 0, 21, 32));
    this->sprites[2].setTextureRect(IntRect(0 + 21 * this->digits[2], 0, 21, 32));
}


// Method for subtracting from the value represented by the DigitCounter instance.
void DigitCounter::subtract() {
    // Check the value of the digits array and perform the appropriate subtraction.
    if (this->digits[2] != 0 && this->digits[1] != 0 && this->digits[0] != 10) {
        this->digits[2]--;
    } else if (this->digits[2] == 0 && this->digits[1] != 0 && this->digits[0] != 10){
        this->digits[2] = 9;
        this->digits[1]--;
    } else if (this->digits[1] == 0 && this->digits[0] == 0 && this->digits[2] != 0) {
        this->digits[2]--;
    } else if (this->digits[2] == 0 && this->digits[1] == 0 && this->digits[0] == 0) {
        this->digits[0] = 10;
        this->digits[1] = 0;
        this->digits[2]++;
    } else if (this->digits[0] == 10 && this->digits[2] != 9) {
        this->digits[2]++;
    } else if (this->digits[0] == 10 && this->digits[2] == 9) {
        this->digits[2] = 0;
        this->digits[1]++;
    } else if (this->digits[0] == 10 && this->digits[2] == 0 && this->digits[1] > 0) {
        this->digits[2]++;
    }

    // Update the texture rect of each sprite to reflect the updated digits array.
    this->sprites[0].setTextureRect(IntRect(0 + 21 * this->digits[0], 0, 21, 32));
    this->sprites[1].setTextureRect(IntRect(0 + 21 * this->digits[1], 0, 21, 32));
    this->sprites[2].setTextureRect(IntRect(0 + 21 * this->digits[2], 0, 21, 32));
}

// Constructor for the DigitCounter class that takes a value to initialize the counter with.
DigitCounter::DigitCounter(unsigned int count) {
    // Calculate the first and second digits of the initial value.
    auto first = count / 10 % 10;
    auto second = count % 10;

    // Initialize the digits array with the calculated values.
    this->digits[0] = 0;
    this->digits[1] = first;
    this->digits[2] = second;

    // Set the position of the DigitCounter instance using the setPosition method.
    setPosition(0, 32 * 16);

    // Set the texture of the DigitCounter instance using the setTexture method.
    setTexture("./images/digits.png");

    // Create three Sprite objects using the texture
    this->sprites[0] = Sprite(texture);
    this->sprites[1] = Sprite(texture);
    this->sprites[2] = Sprite(texture);

    // Set the position of each sprite using the position of the DigitCounter instance.
    this->sprites[0].setPosition(position);
    this->sprites[1].setPosition(position.x + 21, position.y);
    this->sprites[2].setPosition(position.x + 42, position.y);

    // Set the texture rect of each sprite using the corresponding digit in the digits array.
    this->sprites[0].setTextureRect(IntRect(0 + 21 * this->digits[0], 0, 21, 32));
    this->sprites[1].setTextureRect(IntRect(0 + 21 * this->digits[1], 0, 21, 32));
    this->sprites[2].setTextureRect(IntRect(0 + 21 * this->digits[2], 0, 21, 32));
}

// Method for setting the position of the DigitCounter instance.
void DigitCounter::add() {
    // Check the value of the digits array and perform the appropriate addition.
    if (this->digits[2] != 9 && this->digits[0] != 10) {
        this->digits[2]++;
    } else if (this->digits[2] == 9 && this->digits[0] != 10){
        this->digits[2] = 0;
        this->digits[1]++;
    } else if (this->digits[2] <= 9 && this->digits[0] == 10 && this->digits[1] == 0) {
        this->digits[2]--;
        if (this->digits[2] == 0) {
            this->digits[0] = 0;
        }
    } else if (this->digits[2] == 0 && this->digits[0] == 10 && this->digits[1] > 0) {
        this->digits[2] = 9;
        this->digits[1]--;
    } else if (this->digits[2] != 9 && this->digits[0] == 10 && this->digits[1] > 0) {
        this->digits[2]--;
    }
    // Update the texture rect of each sprite to reflect the updated digits array.
    this->sprites[0].setTextureRect(IntRect(0 + 21 * this->digits[0], 0, 21, 32));
    this->sprites[1].setTextureRect(IntRect(0 + 21 * this->digits[1], 0, 21, 32));
    this->sprites[2].setTextureRect(IntRect(0 + 21 * this->digits[2], 0, 21, 32));
}

// Method for drawing the DigitCounter instance to the window.
void DigitCounter::reset() {
    // Set the digits array to the initial value.
    this->digits[0] = 5;
    this->digits[1] = 0;
    // Update the texture rect of each sprite to reflect the updated digits array.
    this->sprites[0].setTextureRect(IntRect(0 + 21 * this->digits[0], 0, 21, 32));
    this->sprites[1].setTextureRect(IntRect(0 + 21 * this->digits[1], 0, 21, 32));
}



/* **************************** ButtonClass **************************** */

// Default constructor for the ButtonClass class.
ButtonClass::ButtonClass() {
    // Set the position of the button using a setPosition method.
    setPosition(12 * 32, 16 * 32);

    // Set the texture of the button using a setTexture method.
    setTexture("./images/face_happy.png");

    // Set the sprite of the button using a setSprite method.
    setSprite();
}

// Constructor for the ButtonClass class that takes a Vector2f object for the position and an integer for the type.
ButtonClass::ButtonClass(const Vector2f& position, int type) {
    // Assign the Vector2f object to the position property of the ButtonClass instance.
    this->position = position;

    // Check the type of the ButtonClass instance and set the texture accordingly.
    if (type == 0) {
        setTexture("./images/debug.png");
    } else if (type == 1) {
        setTexture("./images/test_1.png");
    }
    else if (type == 2) {
        setTexture("./images/test_2.png");
    }
    else if (type == 3) {
        setTexture("./images/test_3.png");
    }

    // Set the sprite of the ButtonClass instance using the setSprite method.
    setSprite();
}

// Constructor for the ButtonClass class that takes two float values for the x and y coordinates and an integer for the type.
ButtonClass::ButtonClass(float x, float y, int type) {
    // Set the position of the ButtonClass instance using the setPosition method.
    setPosition(x, y);

    // Check the type of the ButtonClass instance and set the texture accordingly.
    if (type == 0) {
        setTexture("./images/debug.png");
    } else if (type == 1) {
        setTexture("./images/test_1.png");
    }
    else if (type == 2) {
        setTexture("./images/test_2.png");
    }
    else if (type == 3) {
        setTexture("./images/test_3.png");
    }

    // Set the sprite of the ButtonClass instance using the setSprite method.
    setSprite();
}


/* **************************** Assets **************************** */

// Sets the texture of the Assets instance.
// Takes a Texture object as an argument.
void Assets::setTexture(Texture texture) {
    // Assign the Texture object to the texture property of the Assets instance.
    this->texture = texture;

    // Call the setSprite method to update the sprite property of the Assets instance.
    setSprite();
}

// Sets the sprite of the Assets instance.
void Assets::setSprite() {
    // Create a new Sprite object using the texture property of the Assets instance.
    this->sprite = Sprite(this->texture);

    // Set the position of the sprite using the position property of the Assets instance.
    this->sprite.setPosition(this->position.x, this->position.y);
}

// Sets the texture of the Assets instance from a file.
// Takes a string specifying the file path as an argument.
void Assets::setTexture(string textureFile) {
    try {
        // Attempt to load the texture from the file specified by the textureFile argument.
        this->texture.loadFromFile(textureFile);
    } catch (exception e) {}

    // Call the setSprite method to update the sprite property of the Assets instance.
    setSprite();
}

// Sets the position of the Assets instance.
// Takes a Vector2f object as an argument.
void Assets::setPosition(Vector2f position) {
    // Assign the Vector2f object to the position property of the Assets instance.
    this->position = position;
}

// Sets the position of the Assets instance.
// Takes two float values for the x and y coordinates as arguments.
void Assets::setPosition(float x, float y) {
    // Assign the x and y arguments to the x and y properties of the position property of the Assets instance.
    this->position.x = x;
    this->position.y = y;
}


/* **************************** MineClass **************************** */

MineClass::MineClass() { // default constructor
    setPosition(0,0); // sets the position to (0,0)
    setTexture("./images/mine.png"); // sets the texture to the mine image
    setSprite(); // sets the sprite using the texture
}

MineClass::MineClass(Vector2f position) { // constructor that takes a Vector2f as an argument
    setPosition(position); // sets the position to the given Vector2f
}

MineClass::MineClass(float x, float y) { // constructor that takes x and y as arguments
    setPosition(x, y); // sets the position to the given x and y values
    setTexture("./images/mine.png"); // sets the texture to the mine image
    setSprite(); // sets the sprite using the texture
}

