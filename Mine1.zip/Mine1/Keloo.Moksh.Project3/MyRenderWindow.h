#pragma once

#include <SFML/Graphics.hpp>
#include "BoardSetup.h"

class MyRenderWindow : public RenderWindow {
public:
    MyRenderWindow(VideoMode gameMode, const String& gameTitle, Uint32 gameStyle = Style::Default, const ContextSettings& settings = ContextSettings());



//    void drawTile(const TileState *tile);
//
//    void drawMine(const MineClass *mine);
//
//    void drawFlag(const PlaceFlags *flag);
//
//    void drawCounter(const DigitCounter *counter);
    void draw(const BoardSetup& boardSetup);
};

