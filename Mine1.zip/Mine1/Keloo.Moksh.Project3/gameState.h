#pragma once

// enum Face for the face of the game
enum Face {
    win,
    lose,
    happy
};

// enum for the type of the button
enum State {
    hidden,
    revealed
};