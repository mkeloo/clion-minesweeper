#pragma once

#include <SFML/Graphics.hpp>
using namespace sf;
using namespace std;

class Assets {
private:
public:
// The position member variable is a 2D vector of floats.
    Vector2f position;

// The texture member variable is a texture object.
    Texture texture;

    // The setTexture() function sets the texture member variable by loading the texture from the given file.
    void setTexture(string textureFile);

// The setPosition() function sets the position member variable to the given 2D vector.
    void setPosition(Vector2f position);

// The setPosition() function sets the position member variable to the given coordinates.
    void setPosition(float x, float y);

// The setSprite() function sets the sprite member variable using the position and texture member variables.
    void setSprite();


    // The sprite member variable is a sprite object.
    Sprite sprite;

// The setTexture() function sets the texture member variable to the given texture object.
    void setTexture(Texture texture);


};


