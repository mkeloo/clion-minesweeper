#pragma once

#include "Assets.h"

class ButtonClass : public Assets {
public:
    ButtonClass();
    ButtonClass(const Vector2f& position, int type);
    ButtonClass(float x, float y, int type);
};
