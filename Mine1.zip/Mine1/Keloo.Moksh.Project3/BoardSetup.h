#pragma once
#include <fstream>
#include "TileState.h"
#include "Mine.h"
#include "FaceButton.h"
#include "PlaceFlags.h"
#include "DigitCounter.h"

class BoardSetup {
private:
public:
    unsigned int checkForMines;
    bool DebugSta;
    State stateWant;
    FaceButton* mainButton;
    BoardSetup(unsigned int i);
    void loadMines(unsigned int i);
    ~BoardSetup();
    void setMines();
    bool hasWon();
    MineClass* gridForMines[25][16];
    BoardSetup();
    DigitCounter* counter;
    TileState* gridForTile[25][16];
    ButtonClass* buttons[4];
    void setDebug();
};
