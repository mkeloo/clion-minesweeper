#pragma once

#include "ButtonClass.h"
#include "gameState.h"

class FaceButton : public ButtonClass {
private:

public:
    Face face;
    FaceButton();
    FaceButton(float x, float y, Face face);
    void setFace(Face face);
    FaceButton(Vector2f position, Face face);
};
