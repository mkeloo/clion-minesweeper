#include "MyRenderWindow.h"
#include "BoardSetup.h"

using namespace std;

/* **************************** Rendering Window **************************** */

MyRenderWindow::MyRenderWindow(VideoMode gameMode, const String& gameTitle, Uint32 gameStyle, const ContextSettings& settings) : RenderWindow(gameMode, gameTitle, gameStyle, settings) {
}

void MyRenderWindow::draw(const BoardSetup& boardSetup) {
    // Iterate over each tile on the game board
    for (unsigned int index = 0; index < 25; index++) {
        for (unsigned int j = 0; j < 16; j++) {
            // Check if the tile should be gridForTile
            if (boardSetup.stateWant == revealed || boardSetup.gridForTile[index][j]->state == revealed) {
                // If the tile should be revealed, draw its sprite
                RenderWindow::draw(boardSetup.gridForTile[index][j]->sprite);

                // If the tile has a mine, also draw the mine's sprite
                if (boardSetup.gridForMines[index][j] != nullptr) {
                    RenderWindow::draw(boardSetup.gridForMines[index][j]->sprite);
                }
            } else {
                // If the tile should not be revealed,
                // first check if it has a mine and draw the mine's sprite if it does
                if (boardSetup.gridForMines[index][j] != nullptr) {
                    RenderWindow::draw(boardSetup.gridForMines[index][j]->sprite);
                }

                // Then draw the tile's sprite
                RenderWindow::draw(boardSetup.gridForTile[index][j]->sprite);
            }

            // If the tile's flag is revealed, draw the flag's sprite
            if (boardSetup.gridForTile[index][j]->flag->state == revealed) {
                RenderWindow::draw(boardSetup.gridForTile[index][j]->flag->sprite);
            }

            // If the tile has been revealed and has a non-zero counter and no mine, draw the corresponding counter sprite
            if (boardSetup.gridForTile[index][j]->state == revealed && boardSetup.gridForTile[index][j]->counter->count != 0 &&
                    boardSetup.gridForTile[index][j]->hasMine == false) {
                RenderWindow::draw(boardSetup.gridForTile[index][j]->counter->sprites[boardSetup.gridForTile[index][j]->counter->count - 1]);
            }
        }
    }


    // Draw the "debug" text if the debug state is true
    for (unsigned int index = 0; index < 4; index++) {
        // Draw each button sprite in the button array
        RenderWindow::draw(boardSetup.buttons[index]->sprite);
    }

    // Draw the main button sprite
    RenderWindow::draw(boardSetup.mainButton->sprite);

    // Draw each counter sprite in the counter sprite array
    for (unsigned int index = 0; index < 3; index++) {
        RenderWindow::draw(boardSetup.counter->sprites[index]);
    }
}

//void MyRenderWindow::drawTile(const TileState* tile) {
//    RenderWindow::draw(tile->sprite);
//}
//
//void MyRenderWindow::drawMine(const MineClass* mine) {
//    RenderWindow::draw(mine->sprite);
//}
//
//void MyRenderWindow::drawFlag(const PlaceFlags* flag) {
//    RenderWindow::draw(flag->sprite);
//}
//
//void MyRenderWindow::drawCounter(const DigitCounter* counter) {
//    RenderWindow::draw(counter->sprites[counter->count - 1]);
//}
//




/* **************************** BoardSetup **************************** */

// This code defines a constructor for the BoardSetup class.
BoardSetup::BoardSetup() {
// The `DebugSta` member variable is set to `false`.
    DebugSta = false;
// The `stateWant` member variable is set to the `hidden` value.
    stateWant = hidden;
// The `checkForMines` member variable is set to `50`.
    checkForMines = 50;
// The `setMines()` function is called to set the mine positions.
    setMines();

// A nested loop iterates over the indices of a 25x16 grid.
    for (unsigned int index = 0; index < 25; index++) {
        for (unsigned int j = 0; j < 16; j++) {

            // If the current position contains a mine, a new `TileState` object is created with its `mine` member variable set to `true`.
            if (gridForMines[index][j] != nullptr) {
                gridForTile[index][j] = new TileState(hidden, index * 32, j * 32, true);

                // If the current position does not contain a mine, a new `TileState` object is created with its `mine` member variable set to `false`.
            } else {
                gridForTile[index][j] = new TileState(hidden, index * 32, j * 32, false);
            }
        }
    }

// Another nested loop iterates over the indices of the 25x16 grid again.
    for (int index = 0; index < 25; index++) {
        for (int j = 0; j < 16; j++) {

            // Another nested loop iterates over the offsets in the x and y directions.
            for (int h = -1; h <= 1; h++) {
                for (int k = -1; k <= 1; k++) {

                    // If the current position is within the bounds of the grid, and the current offset is not (0, 0), the current `TileState` object is added to the list of adjacent tiles for the `TileState` object at the current position.
                    if (index + h > -1 && index + h < 25 && j + k > -1 && j + k < 16 && (h != 0 || k != 0)) {
                        gridForTile[index][j]->adjacentTiles.push_back(gridForTile[index + h][j + k]);
                    }
                }
            }
        }
    }

    // A loop iterates over the indices of an array of ButtonClass objects.
    for (unsigned int index = 0; index < 4; index++) {
    // A new `ButtonClass` object is created at position `(i * 64 + (32 * 25 - 64 * 4), 16 * 32)` and with index `i`, and is stored in the array at index `i`.
        buttons[index] = new ButtonClass(index * 64 + (32 * 25 - 64 * 4), 16 * 32, index);
    }
    // A new FaceButton object is created and stored in the mainButton member variable.
    mainButton = new FaceButton();
    // A new DigitCounter object is created with the given checkForMines value and is stored in the counter member variable.
    counter = new DigitCounter(checkForMines);
}

BoardSetup::BoardSetup(unsigned int i) {
    DebugSta = false;
    stateWant = hidden;
    loadMines(i);
    // It first creates a 25x16 grid of TileState objects, where each element is either hidden and potentially containing a mine (if the corresponding element in gridForMines is not nullptr), or hidden and not containing a mine.
    for (unsigned int index = 0; index < 25; index++) {
        for (unsigned int j = 0; j < 16; j++) {
            if (gridForMines[index][j] != nullptr) {
                // If the current position contains a mine, a new TileState object is created with its mine member variable set to true.
                gridForTile[index][j] = new TileState(hidden, index * 32, j * 32, true);
            } else {
                // If the current position does not contain a mine, a new TileState object is created with its mine member variable set to false.
                gridForTile[index][j] = new TileState(hidden, index * 32, j * 32, false);
            }
        }
    }

    // Then, for each element in the grid, it adds all adjacent elements (including diagonal elements) to its list of adjacent tiles.
    for (int index = 0; index < 25; index++) {
        for (int j = 0; j < 16; j++) {
            for (int h = -1; h <= 1; h++) {
                for (int k = -1; k <= 1; k++) {
                    // If the current position is within the bounds of the grid, and the current offset is not (0, 0),
                    // the current `TileState` object is added to the list of adjacent tiles for the `TileState` object at the current position.
                    if (index + h > - 1 && index + h < 25 && j + k > -1 && j + k < 16) {
                        if (h != 0 || k != 0) {
                            gridForTile[index][j]->adjacentTiles.push_back(gridForTile[index + h][j + k]);
                        }
                    }
                }
            }
        }
    }
    // A loop iterates over the indices of an array of ButtonClass objects.
    for (unsigned int index = 0; index < 4; index++) {
        // A new `ButtonClass` object is created at position `(i * 64 + (32 * 25 - 64 * 4), 16 * 32)` and with index `i`, and is stored in the array at index `i`.
        buttons[index] = new ButtonClass(index * 64 + (32 * 25 - 64 * 4), 16 * 32, index);
    }
    // A new FaceButton object is created and stored in the mainButton member variable.
    mainButton = new FaceButton();
    // A new DigitCounter object is created with the given checkForMines value and is stored in the counter member variable.
    counter = new DigitCounter(checkForMines);
}

// This function initializes a grid of 25x16 "gridForMines" elements and sets each element to nullptr.
void BoardSetup::setMines() {
    for (unsigned int index = 0; index < 25; index++) {
        for (unsigned int j = 0; j < 16; j++) {
            gridForMines[index][j] = nullptr;
        }
    }

    // Create a vector of 2-dimensional vectors called "options", which will be used to store the coordinates (i, j) for each cell in the mine grid.
    vector<vector<int>> options;
    for (int index = 0; index < 25; index++) {
        for (int j = 0; j < 16; j++) {
            options.push_back({index, j});
        }
    }

    // Shuffle the "options" vector randomly using the "random_shuffle" function from the standard library.
    random_shuffle(options.begin(),options.end());

    // Pop the first "checkForMines" coordinates from the end of the "options" vector and use them to create new "MineClass" objects.
    // These objects are then added to the corresponding cells in the "gridForMines".
    for (unsigned int number = 0; number < checkForMines; number++) {
        auto choice = options.back();
        options.pop_back();
        int index = choice[0], j = choice[1];
        gridForMines[index][j] = new MineClass(index * 32, j * 32);
    }
}

// This is the destructor for the "BoardSetup" class.
BoardSetup::~BoardSetup() {
    // Delete all the elements of the "gridForTile" array.
    for (unsigned int index = 0; index < 25; index++) {
        for (unsigned int j = 0; j < 16; j++) {
            delete gridForTile[index][j];
        }
    }

    // Delete all the elements of the "buttons" array.
    for (unsigned int index = 0; index < 4; index++) {
        delete buttons[index];
    }

    // Delete the "mainButton" object.
    delete mainButton;

    // Delete all the elements of the "gridForMines" array.
    for (unsigned int index = 0; index < 25; index++) {
        for (unsigned int j = 0; j < 16; j++) {
            delete gridForMines[index][j];
        }
    }
    // Delete the "counter" object.
    delete counter;
}

// This function checks if the player has won the game.
bool BoardSetup::hasWon() {
    // Initialize a variable to count the number of revealed tiles that do not have mines.
    unsigned int tileCount = 0;

    // Loop through the elements of the "gridForTile" array and increment "tileCount" if a tile is revealed and does not have a mine.
    for (unsigned int index = 0; index < 25; index++) {
        for (unsigned int j = 0; j < 16; j++) {
            if (gridForTile[index][j]->hasMine == false && gridForTile[index][j]->state == revealed) {
                tileCount++;
            }
        }
    }

    // If all the tiles that do not have mines have been revealed, the player has won the game.
    // In this case, set the state of all tiles and mines to revealed and return true.
    if (tileCount == 25 * 16 - checkForMines) {
        for (unsigned int index = 0; index < 25; index++) {
            for (unsigned int j = 0; j < 16; j++) {
                if (gridForTile[index][j]->hasMine == false) {
                    gridForTile[index][j]->setState(revealed);
                } else {
                    gridForTile[index][j]->flag->state = revealed;
                }
            }
        }
        return true;
    }

    // If the player has not won, return false.
    return false;
}

// This function loads the locations of mines from a file and sets up the "gridForMines" array.
void BoardSetup::loadMines(unsigned int i) {
    // Initialize the "checkForMines" variable to 0.
    checkForMines = 0;

    // Create an array to store the locations of mines.
    bool minePlaces[25 * 16];

    // Set all elements of the "gridForMines" array to nullptr.
    for (unsigned int index = 0; index < 25; index++) {
        for (unsigned int j = 0; j < 16; j++) {
            gridForMines[index][j] = nullptr;
        }
    }

    // Set all elements of the "minePlaces" array to false (i.e., no mines are placed yet).
    for (unsigned int index = 0; index < 25 * 16; index++) {
        minePlaces[index] = 0;
    }

    // Open the file "./boards/testboard" + the given index + ".brd" and read in the locations of mines.
    ifstream file("./boards/testboard" + to_string(i) + ".brd");
    int checker = 0;
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            // Loop through each character in the line.
            for (char each : line) {
                // If the character is '1', set the corresponding element in the "minePlaces" array to true (i.e., a mine is placed at this location).
                if (each == '1') {
                    minePlaces[checker] = true;
                } else if (each == '0') {
                    // If the character is '0', set the corresponding element in the "minePlaces" array to false (i.e., no mine is placed at this location).
                    minePlaces[checker] = false;
                } else {
                    // If the character is not '1' or '0', ignore it.
                    continue;
                }
                // Increment the "checker" variable.
                checker++;
            }
        }
        // Close the file.
        file.close();
    }

// Reset the "checker" variable to 0.
    checker = 0;

    // Loop through the elements of the "minePlaces" array and create new "MineClass" objects for each location that has a mine.
    // These objects are then added to the corresponding cells in the "gridForMines" array.
    // The "checkForMines" variable is also incremented for each mine that is added to the grid.
    for (unsigned int j = 0; j < 16; j++) {
        for (unsigned int index = 0; index < 25; index++) {
            if (minePlaces[checker] == true) {
                // setting the mines
                gridForMines[index][j] = new MineClass(index * 32, j * 32);
                checkForMines++;
            }
            checker++;
        }
    }
}


// This function sets the debug state of the game.
void BoardSetup::setDebug() {
    // If the current desired state is "hidden", set it to "revealed" and set the debug state to false.
    if (stateWant == hidden) {
        stateWant = revealed;
        DebugSta = false;
    } else {
    // If the current desired state is not "hidden", set it to "hidden" and set the debug state to true.
        stateWant = hidden;
        DebugSta = true;
    }
}

