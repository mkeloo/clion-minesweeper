#pragma once

#include "MyRenderWindow.h"

class Minesweeper {
private:
public:
    BoardSetup* board;
    void gameStart();
    float width;
    float height;
    Minesweeper();
    MyRenderWindow* window;

};
