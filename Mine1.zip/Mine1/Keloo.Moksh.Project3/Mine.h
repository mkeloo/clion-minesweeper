
#pragma once

#include "Assets.h"

class MineClass : public Assets {
private:
public:
    MineClass();
    MineClass(float x, float y);
    MineClass(Vector2f position);

};
