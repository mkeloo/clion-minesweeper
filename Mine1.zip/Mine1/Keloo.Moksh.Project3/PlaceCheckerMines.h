#pragma once
#include "Assets.h"

class PlaceCheckerMines : public Assets {
private:

public:
    int count;
    Texture textures[8];
    PlaceCheckerMines(float x, float y);
    PlaceCheckerMines(int count, float x, float y);
    Sprite sprites[8];
    PlaceCheckerMines();
    void setCount(int count);
};
