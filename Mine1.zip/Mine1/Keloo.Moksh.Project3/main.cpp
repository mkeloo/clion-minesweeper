
#include <stdio.h>
#include <iostream>
#include "mainGame.h"

using namespace sf;

// This is the constructor for the "Minesweeper" class.
Minesweeper::Minesweeper() {
    // Set the width and height of the game window.
    this->width = 800;
    this->height = 600;

    // Create a new "MyRenderWindow" object with the specified width, height, title, and style.
    this->window = new MyRenderWindow(VideoMode(width, height), "Minesweeper", Style::Close | Style::Titlebar);

    // Create a new "BoardSetup" object.
    this->board = new BoardSetup;
}


// This method is the main game loop for Minesweeper
void Minesweeper::gameStart() {

// Initialize the stateCurrent and statePrevious counters to 0 and 1, respectively
    unsigned int statePrevious = 0;
    unsigned int stateCurrent = 1;

// While the game window is open,
    while(window->isOpen()) {
        // Create a new Event object
        Event ObjectEve;

        // While there are ObjectEve in the ObjectEve queue,
        while (window->pollEvent(ObjectEve)) {
            // If the ObjectEve is a window close ObjectEve,
            if (ObjectEve.type == Event::Closed) {
                // Increment the curr counter
                stateCurrent++;
                // Close the game window
                window->close();
            }

            // If the ObjectEve is a keyboard ObjectEve and the Escape key was pressed,
            if (ObjectEve.type == Event::KeyPressed && ObjectEve.key.code == Keyboard::Escape) {
                // Increment the curr counter
                stateCurrent++;
                // Close the game window
                window->close();
            }

            // If the ObjectEve is a mouse button release ObjectEve,
            if (ObjectEve.type == Event::MouseButtonReleased) {
                // Get the current mouse position relative to the game window
                auto mousePos = Mouse::getPosition(*window);

                //new game
                // This code checks if the player has clicked on any of the game's buttons.
                // If a button is clicked, it performs the corresponding action (e.g., reset the game, set the debug state, etc.).

                // Check if the player has clicked the main button.
                if (mousePos.x > board->mainButton->position.x && mousePos.x < board->mainButton->position.x + 64) {
                    if (mousePos.y > board->mainButton->position.y && mousePos.y < board->mainButton->position.y + 64) {
                        // If the main button is clicked, reset the game by deleting the current "BoardSetup" object and creating a new one.
                        stateCurrent++;
                        delete board;
                        board = new BoardSetup();
                    }
                }

                // Loop through the buttons array and check if the player has clicked any of the buttons.
                for (unsigned int index = 0; index < 4; index++) {
                    if (ObjectEve.mouseButton.button == Mouse::Left) {
                        if (mousePos.x > board->buttons[index]->position.x && mousePos.x < board->buttons[index]->position.x + 64) {
                            if (mousePos.y > board->buttons[index]->position.y && mousePos.y < board->buttons[index]->position.y + 64) {
                                // If button 0 is clicked, set the debug state.
                                if (index == 0) {
                                    board->setDebug();
                                } else {
                                    // If any other button is clicked
                                    delete board;
                                    board = new BoardSetup(index);
                                }
                                stateCurrent++;
                            }
                        }
                    }
                }

                // This code handles the player's actions when tapping a tile in the game.
                // If the main button is in the "happy" state (i.e., the game is not over),
                if (board->mainButton->face == happy) {
                    // Check if the player has clicked the left mouse button.
                    if (ObjectEve.mouseButton.button == Mouse::Left) {
                        // Loop through the "gridForTile" array and check if the player has clicked on a tile.
                        for (unsigned int index = 0; index < 25; index++) {
                            for (unsigned int j = 0; j < 16; j++) {
                                if (mousePos.x > index * 32 && mousePos.x < index * 32 + 32) {
                                    if (mousePos.y > j * 32 && mousePos.y < j * 32 + 32) {
                                        // If the player has clicked on a tile, check if it has a flag on it.
                                        if (board->gridForTile[index][j]->flag->state != revealed) {
                                            // If the tile does not have a flag on it, check if it has a mine.
                                            if (board->gridForTile[index][j]->hasMine) {
                                                // If the tile has a mine, reveal all mines and set the main button to the "lose" state.
                                                for (unsigned int k = 0; k < 25; k++) {
                                                    // This for loop iterates through the 16 tiles in the current row (k) of the board
                                                    for (unsigned int h = 0; h < 16; h++) {
                                                        // If the current tile has a mine,
                                                        if (board->gridForTile[k][h]->hasMine) {
                                                            // If the current tile's flag has been revealed,
                                                            if (board->gridForTile[k][h]->flag->state == revealed) {
                                                                // Increment the curr counter
                                                                stateCurrent++;
                                                                // Set the current tile's flag state to hidden
                                                                board->gridForTile[k][h]->flag->setState(hidden);
                                                            }
                                                            // Increment the curr counter
                                                            stateCurrent++;
                                                            // Set the state of the current tile to revealed
                                                            board->gridForTile[k][h]->setState(revealed);
                                                        }
                                                    }
                                                }
                                                stateCurrent++;
                                                board->counter->subtract();
                                                board->mainButton->setFace(lose);
                                            }
                                            // Increment curr
                                            stateCurrent++;

                                            // Set the state of the current tile to revealed
                                            board->gridForTile[index][j]->setState(revealed);

                                            // If the current tile has a mine, do nothing
                                            if (board->gridForTile[index][j]->hasMine) {
                                                // If the current tile has a mine, do nothing
                                            }
                                            else {
                                                // Increment curr and uncover adjacent tiles
                                                stateCurrent++;
                                                board->gridForTile[index][j]->uncoverAdjacent();
                                            }

                                            // If the current tile's flag is revealed, set it to hidden
                                            // and increment the counter
                                            if (board->gridForTile[index][j]->flag->state == revealed) {
                                                stateCurrent++;
                                                board->gridForTile[index][j]->flag->setState(hidden);
                                                board->counter->add();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // This code handles the player's actions when flagging a tile in the game.
                    // Check if the player has clicked the right mouse button.
                    if (ObjectEve.mouseButton.button == Mouse::Right) {
                        // Loop through the "gridForTile" array and check if the player has clicked on a tile.
                        for (unsigned int index = 0; index < 25; index++) {
                            for (unsigned int j = 0; j < 16; j++) {
                                if (mousePos.x > index * 32 && mousePos.x < index * 32 + 32) {
                                    if (mousePos.y > j * 32 && mousePos.y < j * 32 + 32) {
                                        // If the player has clicked on a hidden tile, toggle its flag state.
                                        if (board->gridForTile[index][j]->state == hidden) {
                                            if (board->gridForTile[index][j]->flag->state == revealed) {
                                                board->gridForTile[index][j]->flag->setState(hidden);
                                                // If the flag is removed, add 1 to the counter.
                                                board->counter->add();
                                            } else {
                                                board->gridForTile[index][j]->flag->setState(revealed);
                                                // If the flag is added, subtract 1 from the counter.
                                                board->counter->subtract();
                                            }
                                            stateCurrent++;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (board->hasWon()) {
                        stateCurrent++;
                        board->mainButton->setFace(win);
                    }
                }
            }
        }

        // This code updates the game's window.
        // If the game state has changed,
        if (stateCurrent != statePrevious) {
            // Update the previous game state.
            statePrevious = stateCurrent;
            // Clear the window.
            window->clear();
            // Draw the game's board on the window.
            window->draw(*board);
            // Display the updated window.
            window->display();
        }
    }
}

int main() {
    // Create a Minesweeper object.
    Minesweeper minesweeper;

    // Start the game function.
    minesweeper.gameStart();

    // End the program successfully.
    return 0;
}