#pragma once

#include "Assets.h"
#include "gameState.h"

class PlaceFlags : public Assets {
private:
public:
// public member variables
    State state; // the state of the flag (hidden, revealed, etc.)

// public member functions
    PlaceFlags(Vector2f position); // constructor that takes a Vector2f object as an argument
    PlaceFlags(float x, float y); // constructor that takes the x and y coordinates as arguments
    void setState(State state); // function to set the state of the flag
    PlaceFlags(); // default constructor

};