
#pragma once

#include "gameState.h"
#include "Assets.h"
#include "PlaceCheckerMines.h"
#include "PlaceFlags.h"
using namespace std;

class TileState : public Assets {
private:

public:
    vector<TileState*> adjacentTiles;
    PlaceCheckerMines* counter;
    bool hasMine;
    State state;
    PlaceFlags* flag;
    void setTexture(State checkState);
    void setState(State checkState);
    void setHasMine(bool hasMine);
    void uncoverAdjacent();
    void setCounter(int count);
    TileState();
    ~TileState();
    TileState(State checkState, Vector2f position, bool hasMine);
    TileState(State checkState, float x, float y, bool hasMine);
};
