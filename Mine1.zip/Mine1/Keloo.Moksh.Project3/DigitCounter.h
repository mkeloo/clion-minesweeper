#pragma once
#include "Assets.h"

class DigitCounter : public Assets {
private:
public:
    unsigned int digits[3];
    void reset();
    DigitCounter();
    Sprite sprites[3];
    void subtract();
    void add();
    DigitCounter(unsigned int count);

};
